// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("android armv7"); }
int main(){
  announce();
  return lionss_run_workload("android-armv7");
}
