// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("oss fuzz sync\n", stdout);
  return lionss_run_workload("oss-fuzz-sync");
}
