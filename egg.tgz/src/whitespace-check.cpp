// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("whitespace check"); }
int main(){
  announce();
  return lionss_run_workload("whitespace-check");
}
