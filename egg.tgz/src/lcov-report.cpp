// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("lcov report\n", stdout);
  return lionss_run_workload("lcov-report");
}
